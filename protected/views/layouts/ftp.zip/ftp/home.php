<?php


$resource = ftp_connect('u84895.your-backup.de');
$login = ftp_login($resource, 'u84895', 'sqjvpTGoowYtku2u');
$list = ftp_rawlist($resource, '');

print_r($list)
?>