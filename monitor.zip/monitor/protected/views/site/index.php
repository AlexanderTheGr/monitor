<?php $this->pageTitle = Yii::app()->name; ?>
<?php //$this->ls = Langtranslater::getSingleton(array('page_key' => $this->getPageKey(), 'lang' => $this->lang, 'create' => true));?>
<div style="text-align: center">
    <h1>Καλως ήρθατε στο Parts Box της FastWeb</h1>
    
</div>