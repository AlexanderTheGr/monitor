<?php
echo  HtmlWidget::tabber($tabs);
?>
