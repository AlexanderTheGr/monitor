
<?php require Yii::app()->params['widget']."datatable.php";?>