<style>

</style>
<?php echo  HtmlWidget::tabber($accordions,array(),false);?>
