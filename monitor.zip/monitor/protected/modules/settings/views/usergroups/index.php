<?php echo  HtmlWidget::tabber($tabs,array(),false);?>
