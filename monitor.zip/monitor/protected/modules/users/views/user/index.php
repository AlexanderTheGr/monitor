<?php require Yii::app()->params['widget']."datatable.php";?>
<script>
    /*
    $(".user").live("click",function(){
        var full_id = $(this).attr("id");
        var idarr = full_id.split("_");
        var id = idarr[1];
        location.href = '<?php echo Yii::app()->params['mainurl']?>/users/user/'+id;
    })
    $(".addnew").live("click",function(){
        location.href = '<?php echo Yii::app()->params['mainurl']?>/users/user/0';
    })    
    
    */
</script>